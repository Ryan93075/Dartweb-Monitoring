import os
import requests
import time
import re
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urljoin

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}
PROXIES = {
    'http': 'socks5h://127.0.0.1:9150',
    'https': 'socks5h://127.0.0.1:9150'
}

os.makedirs("scraped_data", exist_ok=True)
os.makedirs("logs", exist_ok=True)

def check_tor():
    try:
        response = requests.get("https://check.torproject.org/", proxies=PROXIES, timeout=10)
        if "Congratulations" in response.text:
            print("✅ Tor is working correctly!")
            return True
        else:
            print("❌ WARNING: Not using Tor.")
            return False
    except Exception as e:
        print(f"❌ Error checking Tor connection: {e}")
        return False

def extract_onion_links(url):
    try:
        print(f"🔍 Extracting links from {url}...")
        response = requests.get(url, headers=HEADERS, proxies=PROXIES, timeout=15)
        soup = BeautifulSoup(response.content, 'html.parser')

        onion_links = set()
        for link in soup.find_all('a', href=True):
            href = urljoin(url, link['href'])
            if ".onion" in href:
                onion_links.add(href)

        onion_links.update(re.findall(r'(https?://[a-zA-Z0-9]+\.onion\b)', response.text))
        print(f"🔗 Found {len(onion_links)} .onion links.")
        return list(onion_links)

    except Exception as e:
        print(f"❌ Error extracting onion links from {url}: {str(e)}")
        return []


# ✅ Function to download all linked assets (CSS, JS, Images, PDFs, TXT, ZIP, EXE, etc.)
def download_assets(soup, base_url, folder_name):
    for tag in soup.find_all(["img", "script", "link", "a"]):
        attr = "href" if tag.name in ["link", "a"] else "src"
        file_url = tag.get(attr)

        if file_url:
            full_url = urljoin(base_url, file_url)
            download_content(full_url, folder_name)


# ✅ Function to download a single file (supports ALL file types)
def download_content(url, folder_name):
    try:
        print(f"📥 Downloading: {url}")
        response = requests.get(url, headers=HEADERS, proxies=PROXIES, timeout=15)

        if response.status_code == 200:
            content_type = response.headers.get('Content-Type', '')

            # ✅ File extensions mapping
            file_extensions = {
                "text/html": "html", "application/pdf": "pdf",
                "image/png": "png", "image/jpeg": "jpg", "image/svg+xml": "svg",
                "image/gif": "gif", "image/webp": "webp",
                "text/css": "css", "application/javascript": "js",
                "text/plain": "txt", "application/zip": "zip",
                "application/x-rar-compressed": "rar", "application/gzip": "gz",
                "application/x-tar": "tar", "application/octet-stream": "bin",
                "application/x-msdownload": "exe",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
                "application/vnd.ms-powerpoint": "ppt", "audio/mpeg": "mp3",
                "audio/ogg": "ogg", "video/mp4": "mp4", "video/x-matroska": "mkv"
            }

            file_extension = file_extensions.get(content_type, "unknown")
            if file_extension == "unknown":
                print(f"⚠️ Unknown file type: {content_type}. Saving as .bin")
                file_extension = "bin"

            filename = os.path.join(folder_name, f"file_{int(time.time())}.{file_extension}")
            with open(filename, 'wb') as f:
                f.write(response.content)
            print(f"✅ File saved: {filename}")

        else:
            print(f"❌ Failed to retrieve {url}, Status: {response.status_code}")

    except Exception as e:
        print(f"❌ Error downloading {url}: {str(e)}")


# ✅ Function to process and crawl `.onion` sites
def crawl_onion_sites(links):
    for url in links:
        domain = urlparse(url).netloc.replace('.onion', '')
        folder_name = f"scan/{domain}"
        os.makedirs(folder_name, exist_ok=True)

        # ✅ Request the URL and handle errors properly
        try:
            print(f"🛡️ Scanning {url}...")
            response = requests.get(url, headers=HEADERS, proxies=PROXIES, timeout=60)
            response.raise_for_status()

            print(f"✅ Successfully accessed {url}")
        except requests.exceptions.ReadTimeout:
            print(f"⚠️ Timeout while connecting to {url}. Skipping this link.")
            continue
        except requests.exceptions.RequestException as e:
            print(f"❌ Failed to connect to {url}: {e}")
            continue

        # ✅ Download main content
        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')
            with open(os.path.join(folder_name, "index.html"), 'wb') as f:
                f.write(response.content)

            # ✅ Download all linked assets (CSS, JS, images, PDFs, TXT, etc.)
            download_assets(soup, url, folder_name)

        # ✅ Extract and follow new onion links
        new_links = extract_onion_links(url)
        for new_link in new_links:
            if new_link not in links:
                links.append(new_link)


# ✅ Function to start crawling
def start_crawl():
    search_engine_url = input("🔍 Enter the site URL to start crawling: ").strip()
    print(f"🚀 Starting crawl at: {search_engine_url}")

    # ✅ Add the initial URL to the list before extracting new links
    indexed_links = [search_engine_url] + extract_onion_links(search_engine_url)

    if not indexed_links:
        print("❌ No onion links found! Retrying...")
        time.sleep(5)
        indexed_links = extract_onion_links(search_engine_url)

    if not indexed_links:
        print("❌ Still no onion links found! Check if the search engine returns valid HTML.")
        return

    # ✅ Step 2: Crawl extracted `.onion` sites, including the initial one
    crawl_onion_sites(indexed_links)


# ✅ Run the crawler
if __name__ == '__main__':
    if check_tor():
        start_crawl()
