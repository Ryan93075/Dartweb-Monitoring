from bs4 import BeautifulSoup
import os
import torch
import numpy as np
import re
import time
import random
import pandas as pd
import torch.nn.functional as F
from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments
from torch.utils.data import Dataset
from pymongo import MongoClient
from sklearn.utils.class_weight import compute_class_weight
from torch.nn import CrossEntropyLoss

# Load dataset
df = pd.read_csv("darkweb_data.csv")

# Convert 5-category labels into 4-category labels
df["label"] = df["label"].replace({4: 3})  # Map "Critical" (4) to "High" (3)
train_texts = df["text"].tolist()
train_labels = df["label"].tolist()

# Set random seeds for reproducibility
torch.manual_seed(42)
torch.cuda.manual_seed_all(42)
np.random.seed(42)
random.seed(42)

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["local"]
collection = db["test_1"]

# Text Cleaning Function
def clean_text(text):
    soup = BeautifulSoup(text, "html.parser")
    text = soup.get_text()
    text = re.sub(r'[^A-Za-z0-9@#%&\s]', '', text)  # Retain important symbols
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# Read File with Encoding Handling
def read_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        with open(file_path, 'r', encoding='ISO-8859-1') as f:
            return f.read()
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
        return ""

# Custom Dataset Class
class CustomDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_length=512):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        encoding = self.tokenizer(
            self.texts[idx],
            padding="max_length",
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt"
        )
        return {"input_ids": encoding["input_ids"].squeeze(),
                "attention_mask": encoding["attention_mask"].squeeze(),
                "labels": torch.tensor(self.labels[idx], dtype=torch.long)}

# Compute Class Weights to Handle Imbalance
class_weights = compute_class_weight("balanced", classes=np.unique(train_labels), y=train_labels)
class_weights = torch.tensor(class_weights, dtype=torch.float)

# Define Temperature Scaling to Reduce Model Overconfidence
def temperature_scaled_softmax(logits, temperature=2.0):
    scaled_logits = logits / temperature
    return F.softmax(scaled_logits, dim=1)

# Train Model Function
def train_model(train_texts, train_labels):
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    dataset = CustomDataset(train_texts, train_labels, tokenizer)
    model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=4)  # Now only 4 labels

    # Adjust loss function for class weights
    loss_fn = CrossEntropyLoss(weight=class_weights)

    training_args = TrainingArguments(
        output_dir='./results',
        num_train_epochs=7,  # Increased epochs
        per_device_train_batch_size=4,
        learning_rate=5e-5,  # Lower learning rate for better tuning
        logging_dir='./logs',
        logging_steps=10,
        save_strategy="epoch"
    )

    # Corrected `compute_metrics` function to avoid tensor issues
    def compute_metrics(eval_pred):
        logits, labels = eval_pred
        loss = loss_fn(torch.tensor(logits), torch.tensor(labels))
        return {"loss": loss.item()}

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset,
        compute_metrics=compute_metrics
    )

    trainer.train()
    model.save_pretrained("./trained_model")
    tokenizer.save_pretrained("./trained_model")
    return model, tokenizer

# Load Pretrained Model
def load_model():
    tokenizer = BertTokenizer.from_pretrained("./trained_model")
    model = BertForSequenceClassification.from_pretrained("./trained_model")
    model.eval()
    return model, tokenizer

# Scan Folders for New Data
def scan_folders(base_directory, model, tokenizer, scanned_files):
    results = []
    id_counter = len(scanned_files) + 1
    severity_levels = ["None", "Low", "Medium", "High"]  # Only 4 categories now

    for folder in os.listdir(base_directory):
        folder_path = os.path.join(base_directory, folder)
        if os.path.isdir(folder_path):
            for subdir, _, files in os.walk(folder_path):
                for file in files:
                    file_path = os.path.join(subdir, file)
                    if file_path in scanned_files:
                        continue

                    try:
                        text = read_file(file_path)
                        text = clean_text(text)
                        if not text:  # Skip empty files
                            continue
                    except Exception:
                        continue

                    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding="max_length", max_length=512)
                    with torch.no_grad():
                        outputs = model(**inputs)

                    # Apply temperature scaling to reduce bias
                    probs = temperature_scaled_softmax(outputs.logits, temperature=2.0)

                    predicted_class = torch.argmax(probs, dim=1).item()
                    severity = severity_levels[min(predicted_class, len(severity_levels) - 1)]

                    results.append({"id": str(id_counter), "onionsite_url": folder, "severity": severity})
                    id_counter += 1
                    scanned_files.add(file_path)

    return results

# Check if Model Needs Training or Loading
if not os.path.exists("./trained_model"):
    print("Training model...")
    model, tokenizer = train_model(train_texts, train_labels)
else:
    print("Loading trained model...")
    model, tokenizer = load_model()

# Start Scanning
scanned_files = set()
base_directory = "scan"

while True:
    data_to_insert = scan_folders(base_directory, model, tokenizer, scanned_files)
    if data_to_insert:
        collection.insert_many(data_to_insert)
    time.sleep(1)
